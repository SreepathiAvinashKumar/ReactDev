import React from "react";
import ReactDOM from "react-dom";
// import {render} from "react-dom"
// import Counter from "./components/counter";
import "bootstrap/dist/css/bootstrap.css";
// import IndexPage from "./components/counters";
// import Counter from "./components/counter";
import App from "../src/App";

// // import {render} from "react-dom";
// import {createRoot} from "react-dom/client"
// // import "./bootstrap-5.1.3-dist/css/bootstrap.css";
// const root = createRoot(container);
// root.render(<Counter/>);

ReactDOM.render(
  // <Counter sampleText="textSample" />,
  // document.getElementById("root")

  <App/>,
  document.getElementById("root")
);

// above sampleText is the props for CounterPage and It is recive the values as props.sampleText
