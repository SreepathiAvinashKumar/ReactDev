import React, { useEffect, useState } from "react";
import Navbar from "../src/components/navbar";
import Counters from "./components/counters";
// import { ReactDOM } from "react";

const App = () => {
  var state = {
    counters: [
      { id: 1, value: 0 },
      { id: 2, value: 0 },
      { id: 3, value: 0 },
      { id: 4, value: 0 },
    ],
  };

  var [cout, setCounters] = useState(state.counters);

  var handleIncrement = (counter) => {
    var counters = [...state.counters];
    const index = counters.indexOf(counter);
    counters[index] = { ...counter };
    counters[index].value++;
    setCounters(counters);

    // counters[0].value++;
    // console.log(counters);
  };

  //Deleting Element
  var handleDelete = (counterId) => {
    setCounters(state.counters.filter((c) => c.id !== counterId));
  };

  useEffect(() => {
    state.counters = cout;
  });

  //Resetting Element
  var handleReset = () => {
    const counters = state.counters.map((count) => {
      count.value = 0;
      return count;
    });

    setCounters(counters);
  };

  const mystyle = {
    marginLeft: "520px",
    marginTop: "80px",
    backgroundColor: "#FFFCF9",
    display: "inline-block",
    border: "black solid 2px ",
    borderRadius: "10%",
  };
  return (
    <React.Fragment>
      <Navbar totalCounters={cout.filter((couts) => couts.value > 0).length} />
      <h1 style={{ textAlign: "center" }} className="h1 me-0 mt-1 bg-warning">
        Counter
      </h1>
      <main className="p-5" style={mystyle}>
        <Counters
          className="card"
          onDelete={handleDelete}
          onIncrement={handleIncrement}
          onReset={handleReset}
          counters={cout}
        />
      </main>
    </React.Fragment>
  );
};

export default App;
