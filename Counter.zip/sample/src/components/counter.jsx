import React /* { useState }*/ from "react";

const Counter = (props) => {
  // var state = {
  //   value: props.counter.value,
  //   // tags: [],
  //   imageUrl:
  //     "https://images.pexels.com/photos/969462/pexels-photo-969462.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  // };

  var classes = "badge m-2 p-3 bg-";

  classes += props.counter.value === 0 ? "danger" : "primary";

  // function renderTags() {
  //   // if (state.tags.length === 0) return <p>There are no tags!</p>;

  //   return (
  //     <ul>
  //       {state.tags.map((tag) => (
  //         <li key={tag}>{tag}</li>
  //       ))}
  //     </ul>
  //   );
  // }

  // var [value, changeIncrement] = useState(props.counter.value);

  // var handleIncrement = () => {
  //   changeIncrement(
  //     ++value,
  //     ++props.counter.value
  //     // console.log(props.sampleText);
  //   );
  // };

  return (
    <React.Fragment>
      {/* {console.log(props)}; */}
      {/* <img src={state.imageUrl} height={250} width={400} alt="" /> */}
      {/* {state.tags.length === 0 && "Please enter the tags"} */}
      {/* you can use this as condition where it returns please enter the tags as left condition is true */}
      {/* {props.children} */}{" "}
      {/*this is the children proporty that used by sending props as html elements */}
      {/* {renderTags()} */}
      <br />
      <span className={classes}>{props.counter.value}</span>
      <button
        onClick={() => props.onIncrement(props.counter)}
        className="btn btn-secondary m-2 "
      >
        Increment
      </button>
      <button
        onClick={() => props.onDelete(props.counter.id)}
        className="btn btn-danger btn-sm m-2"
      >
        Delete
      </button>
    </React.Fragment>
  );
};

export default Counter;
