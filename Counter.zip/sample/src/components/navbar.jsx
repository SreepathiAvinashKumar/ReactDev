import React from "react";

export const navbar = ({ totalCounters }) => {
  // you can pass props by destructing them directly
  return (
    <div>
      <nav className="navbar navbar-dark bg-dark ">
        <div className="container-fluid">
          <a className="navbar-brand" href="{}">
            Navbar{" "}
            <span className="badge m-1 p-1 bg-primary">{totalCounters}</span>
          </a>
        </div>
      </nav>
    </div>
  );
};

export default navbar;
