import React from "react";
import Counter from "./counter";

const IndexPage = (props) => {


  return (
    <div>
      <button onClick={props.onReset} className="btn btn-primary btn-sm mt-3 mb-2 ms-1">
        Reset
      </button>
      {props.counters.map((counter) => (
        <Counter
          counter={counter}
          onDelete={props.onDelete}
          onIncrement={props.onIncrement}
          key={counter.id}
        >
          {/* <h4>Counter: {counter.id}</h4> */}{" "}
          {/*this speacial hook used as children sends a props and get by .children class*/}
          {/*props are read only objects where state can written*/}
        </Counter>
      ))}
    </div>
  );
};

export default IndexPage;
